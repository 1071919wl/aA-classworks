module Api::StaticpagesHelper
end
