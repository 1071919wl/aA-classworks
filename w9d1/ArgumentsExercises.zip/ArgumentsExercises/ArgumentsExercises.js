// Arguments Exercises

// sum

// solution 1:
function sum(nums) {
    let count = 0;
    for(let i = 0; i < arguments.length; i++){
        // console.log(arguments[i]);
        count+= arguments[i];
    }
    return count;
}

// console.log(sum(1, 2, 3, 4));

// solution 2: 
function sum2(...args){
    let count = 0;
    for (let i = 0; i < args.length; i++) {
        count += args[i];
    }
    return count
}

// console.log(sum2(1, 2, 3, 4, 5));

// BIND: 

// solution 1
Function.prototype.myBind = function(context, args){
    let that = this;

    return function(arguments){
        return that.apply(context, args.concat(arguments));
    }

}

// solution 2
Function.prototype.myBind = function(context, ...args){
    let that = this;

    return function(...callArgs){
        return that.apply(context, args.concat(callArgs));
    }

}

class Cat {
  constructor(name) {
    this.name = name;
  }

  says(sound, person) {
    console.log(`${this.name} says ${sound} to ${person}!`);
    return true;
  }
}

class Dog {
  constructor(name) {
    this.name = name;
  }
}

const markov = new Cat("Markov");
const pavlov = new Dog("Pavlov");

// markov.says("meow", "Ned");

// markov.says.myBind(pavlov, "meow", "Kush")();
// markov.says.myBind(pavlov, ["meow", "Kush"])();

// markov.says.myBind(pavlov)("meow", "a tree");


// CURRY

function curriedSum(numArgs){
    let nums = [];
    return function _curriedSum(n){
        nums.push(n);
        if(nums.length === numArgs){
            let currentSum = nums.reduce((acc, el) => acc + el);
            return currentSum;
        }else{
            return _curriedSum;
        }
    }
}
const sum4 = curriedSum(4);
// console.log(sum4(5)(30)(20)(1));
 // => 56


//  Solution 1
Function.prototype.curry = function(numArgs){
    let nums = [];
    let fcn = this;
    return function _curried(n){
        nums.push(n);
        if(nums.length === numArgs){
            return fcn(nums);
        } else {
            return _curried;
        }
    }


}

function sum(nums){
    // find sum of nums;

}
// make new function equal to what ^^ returns and then say -> 
const _curried = sum.curry(4)
console.log(_curried(1)(2)(3)(4));

// Solution 2:

Function.prototype.myCurry = function(context, numArgs) {    
    let nums = [];
    let fcn = this;
    return function _myCurried(n){
        nums.push(n);
        if(nums.length === numArgs){
            return fcn.apply(context, nums);
        } else {
            return _myCurried;
        }
    }
}

// Solution 3: SPREAD
Function.prototype.myCurry = function (numArgs) {
    let nums = [];    
    let fcn = this;

    return function _myCurried(n){
        nums.push(n);
        if(nums.length === numArgs){
            return fcn(...nums);
        } else {
            return _myCurried;
        }
    }
}

// Function.prototype.myCurry = function (numArgs) {
//     let nums = [];
//     let fcn = this;

//     return function _myCurried(n) {
//         nums.push(n);
//         if(nums.length < numArgs){
//             return _myCurried;
//         } else {
//             return fcn(...nums)
//         }
//     }
// }



