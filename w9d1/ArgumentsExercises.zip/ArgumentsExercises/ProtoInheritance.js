// Inheritance Exercises

// Surrogate
// Function.prototype.inherits = function(ParentClass){
//     function Surrogate(){}
//     Surrogate.prototype = ParentClass.prototype;
//     this.prototype = new Surrogate();
//     this.prototype.constructor = this;
// }

Function.prototype.inherits2 = function(ParentClass){
    this.prototype = Object.create(ParentClass.prototype);
    this.prototype.constructor = this;
} 


function MovingObject(weight, speed){
    this.weight = weight;
    this.speed = speed;
}

MovingObject.prototype.mySpeed = function(){
    console.log(`My speed is ${this.speed}`)
}

function Asteriod(planet, weight, speed){
    MovingObject.call(this, weight, speed)
    this.planet = planet;
}

Asteriod.inherits2(MovingObject);

Asteriod.prototype.myPlanet = function() {
    console.log(`I am from this ${this.planet}`);
}

function Ship(ocean, weight, speed){
    MovingObject.call(this, weight, speed);
    this.ocean = ocean;
}

Ship.inherits2(MovingObject);

Ship.prototype.myOcean = function() {
    console.log(`My ocean is ${this.ocean}`);
}


let aster = new Asteriod('earth', 1000000, 1000)
let ship = new Ship('atlantic', 1000, 99)
let obj = new MovingObject(500, 90)




// a.weight = 1000
// a.speed = 99



// Correct solution 2
// Object.create
// Rectangle.prototype = Object.create(Shape.prototype);
// Rectangle.prototype.constructor = Rectangle;

// Circle.prototype = Object.create(Shape.prototype);
// Circle.prototype.constructor = Circle;