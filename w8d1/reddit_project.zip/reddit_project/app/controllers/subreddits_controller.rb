class SubredditsController < ApplicationController

    def new
        @subreddit = Subreddit.new
        render :new
    end

    def edit
        @subreddit = Subreddit.find(params[:id])
        render :edit
    end

    def create
        @subreddit = Subreddit.new(subreddit_params)
        if @subreddit.save
            render :show
        else
            flash[:errors] = @subreddit.errors.full_messages
            redirect_to subreddits_url
        end
    end

    def update
        @subreddit = Subreddit.find(params[:id])
        if @subreddit.update(subreddit_params) && current_user.id == @subreddit.mod_id
            render :show
        else
            flash[:errors] = @subreddit.errors.full_messages
            redirect_to subreddits_url
        end
    end

    def show
        @subreddit = Subreddit.find(params[:id])
        render :show
    end

    def index
        @subreddits = Subreddit.all
        render :index
    end

    private

    def subreddit_params
        params.require(:subreddit).permit(:title, :description, :mod_id)    
    end

end
