class PostsController < ApplicationController
    before_action :require_user

    def new
        @post = Post.new
        render :new
    end

    def create
        @post = Post.new(post_params)
        @post.author_id = current_user.id
        if @post.save
            render :show
        else
            flash[:errors] = @post.errors.full_messages
            redirect_to subreddits_url
        end
    end

    def edit
        @post = Post.find(params[:id])
        render :edit
    end

    def update
        @post = Post.find(params[:id])
        if @post.update(post_params)
            render :show
        else
            flash[:errors] = @post.errors.full_messages
            redirect_to subreddits_url
        end
    end

    def show
        @post = Post.find(params[:id])
        render :show
    end

    def destroy
        @post = Post.find(params[:id])
        if current_user.id == @post.author_id
            @post.destroy
        end
        redirect_to subreddits_url
    end

    private
    def post_params
        params.require(:post).permit(:title, :author_id, :url, :content, :sub_id)
    end

end
