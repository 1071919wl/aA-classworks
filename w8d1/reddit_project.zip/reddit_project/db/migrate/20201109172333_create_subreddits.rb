class CreateSubreddits < ActiveRecord::Migration[5.2]
  def change
    create_table :subreddits do |t|
      t.string :title, null: false
      t.string :description, null: false
      t.integer :mod_id, null: false
      t.timestamps
    end
    add_index :subreddits, :title, unique: true
    add_index :subreddits, :mod_id, unique: true
  end
end
