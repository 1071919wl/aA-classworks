import React from 'react';
import Tile from './tile';

class Board extends React.Component{
    constructor(props){
        super(props);

    }
    
    render() {
        let board = this.props.board.grid;
        let updateGame = this.props.updateGame;

        const rows = board.map ( (row, idx) => {
            return (
                <div key={idx}>
                    {
                        row.map ( (tile, idx2) => {
                            return (
                                <Tile key={idx2} tile={tile} updateGame={updateGame}/>
                            )
                        })
                    }
                </div>
            )
        })
        return(
            <ul className="rows" style={{width: board.length}}>{rows}</ul>
        )
    }
}

export default Board;