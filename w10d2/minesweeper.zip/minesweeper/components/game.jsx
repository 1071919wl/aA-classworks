import React from 'react'
import * as Minesweeper from "../minesweeper.js"
import Board from "./board"


class Game extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            board: new Minesweeper.Board(15, 15)
        };

        this.updateGame = this.updateGame.bind(this)
        this.restartGame = this.restartGame.bind(this)
    };

    updateGame(tile, altKey) {
        if(altKey){
            tile.toggleFlag();
        }else{
            tile.explore();
        }
        this.setState({ board: this.state.board })
    };

    restartGame(){
        this.setState({board: new Minesweeper.Board(10, 10)});
    }

    render() {
        let gameover = ''
        if(this.state.board.won()){
            gameover = 'you won!'
        }else if (this.state.board.lost()){
            gameover = 'you lose!'
        }
        let popup = 
            <div className='modal'>
                <div className='modal2'>
                    <p>gameover</p>
                    <button onClick={this.restartGame}>Restart Game</button>
                </div>
            </div>
        return (
            <div className='gameBorder'>
                <h1>Minesweeper</h1>
                <Board board={this.state.board} updateGame={this.updateGame} />
                {popup}
            </div>
        )
    }
};

export default Game;