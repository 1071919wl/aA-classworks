import React from 'react';

class Tile extends React.Component{
    constructor(props){
        super(props);
        
        this.handleClick = this.handleClick.bind(this);
    }

    handleClick(e){
        this.props.updateGame(this.props.tile, e.altKey)
    }

    render() {
        let tile = this.props.tile;
        let display = "";
        let klass = '';

        if(tile.explored){
            if(tile.bombed){
                klass = 'bombed';
                display = '💣';
            }else{
                klass = 'revealed';
                display = tile.adjacentBombCount();
                if (display === 0) display = ''
            }
        }else if (tile.flagged){
            klass = 'flagged';
            display = "\u2691";
        }
        return (
            <div className={`tile ${klass}`} onClick={this.handleClick} >{display}</div>
        )
    }
}
export default Tile;