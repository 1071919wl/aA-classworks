# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
Cat.destroy_all

cat_1 = Cat.create!(birth_date: '10/10/2015', color: "Red", name: "Poppins", sex: "F", description: "A feisty cat, but full of promise" )
cat_2 = Cat.create!(birth_date: '04/10/2019', color: "Black", name: "saly", sex: "M", description: "Likes dog food" )
cat_3 = Cat.create!(birth_date: '11/12/2020', color: "Green", name: "Frog", sex: "F", description: "Not feisty cat." )
cat_4 = Cat.create!(birth_date: '1q0/10/2010', color: "Brown", name: "Dog", sex: "M", description: "Does not like to chase mouse" )
cat_5 = Cat.create!(birth_date: '10/11/2010', color: "Red", name: "Mr. snuggles", sex: "F", description: "Jumps 40ft high." )
cat_6 = Cat.create!(birth_date: '10/05/2010', color: "Orange", name: "Kitty", sex: "M", description: "Likes to sleep and swim." )
