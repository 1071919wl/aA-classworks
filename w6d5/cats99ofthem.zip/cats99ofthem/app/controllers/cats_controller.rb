class CatsController < ApplicationController

    def index
        cats = Cat.all
        render json: cats
    end

    def show
        @cat = Cat.find(params[:id])
        # render json: :cat
        render :show
    end

    def new
        @cat = Cat.new
        # render json: cat
        render :new
    end

    def edit
        @cat = Cat.find_by(id: params[:id])
        render :edit
    end

    def update
      @cat = Cat.find_by(id: params[:id])
      
      if @cat.update_attributes(id: params[:id])
          redirect_to cat_url
      else
        render :edit
      end

    end


end