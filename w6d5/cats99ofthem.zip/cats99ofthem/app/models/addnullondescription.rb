class Addnullondescription < ApplicationRecord
end
