# == Schema Information
#
# Table name: cats
#
#  id          :bigint           not null, primary key
#  birth_date  :date             not null
#  color       :string           not null
#  name        :string           not null
#  sex         :string(1)        not null
#  description :text
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
require 'action_view'

class Cat < ApplicationRecord

    COLOR = ["Red", "Orange", "Black", "Green", "Brown"]

    include ActionView::Helpers::DateHelper
    validates :birth_date, :color, :name, :sex, presence: true
    validates_inclusion_of :color, in: COLOR, on: :create, message: "Your cat can't be clear"
    validates_inclusion_of :sex, :in => %w(M F), length: {maximum:1}, on: :create
end
