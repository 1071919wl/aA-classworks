# REVERSI JS STYLE

To run tests, open `SpecRunner.html` in a chrome tab.

To play the game, run `node run_game.js` in your console.

