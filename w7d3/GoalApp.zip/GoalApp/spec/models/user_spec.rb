# == Schema Information
#
# Table name: users
#
#  id              :bigint           not null, primary key
#  username        :string           not null
#  description     :string           not null
#  password_digest :string           not null
#  session_token   :string           not null
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#
require 'rails_helper'

RSpec.describe User, type: :model do
  subject(:user) {User.create(username: "FrankyJ", password: "123password", description: "Is 40yrs old :(")}
  describe "Validations" do
    it { should validate_presence_of(:username)}
    it { should validate_presence_of(:session_token)}
    it { should validate_presence_of(:description)}
    it { should validate_presence_of(:password_digest)}
    it { should validate_uniqueness_of(:password_digest)}
    it { should validate_uniqueness_of(:session_token)}
  end

  describe '::find_by_credentials' do 
    it 'Should take in a username and password as arugments' do
      expect{User.find_by_credentials("FrankyJ", '123password')}.not_to raise_error
    end

    it 'Return nil if username is not found' do
      expect(User.find_by_credentials("BillyB", 'password123')).to be_falsey
    end

    it 'Return nil if password does not match user' do
      expect(User.find_by_credentials("FrankyJ", 'password123')).to be_falsey
    end

    it 'Return user if username and password match' do
      expect(user = User.find_by_credentials("FrankyJ", '123password')).to eq(user)
    end
  end

  describe '#password= ' do
    it 'Should take in a password as an arugment' do
      expect{user.password=('123password')}.to_not raise_error
    end
    # it 'Should encrypt password' do
    #   expect(BCrypt::Password).to receive(:create).with('123password')
    # end
  end


  

end
