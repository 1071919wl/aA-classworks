require 'rails_helper'

RSpec.describe UsersController, type: :controller do

    describe "get#new" do
        it "render the new user template" do
            get :new
            expect(response).to render_template(:new)
        end
    end
    
    describe "post#create" do
        # let(:user) {{user: }}
        # before(:each)
        # user = User.create(user)
        it "receives valid params" do
            expect{User.create(user = {username: "Bill", password: "1234567", description: "Hello World it's ya boii Bill"})}.not_to raise_error
        end
        it "On successful creation, redirect to user's show page" do
            post :create, params: {user: {username: "Jim", password: "Elephant", description: "Likes fish :)"}}
            # user = User.create(username: "Jim", password: "Elephant", description: "Likes fish :)")
            user = User.find_by(username: 'Jim')
            expect(response).to redirect_to(user_url(user.id))
        end

        it 'if creation is not successful, render the sign up form' do
            post :create, params: {user: {username: "Jim", password: "Elephant", description: "Likes fish :)", fave_food: 'Taco'}}
            get :new

            expect(response). to render_template(:new)
        end
    end

    describe 'user_params' do
        it 'it will only take in then parameter of username, password and description' do 
            # post :create, params: {user: {username: "Jim", password: "Elephant", description: "Likes fish :)", fave_food: 'Taco'}}
            expect(params.require(:user).permit(:username, :description, :password)).to eq(params: {user: {username: "Jim", password: "Elephant", description: "Likes fish :)", fave_food: 'Taco'})
    end



    
    
end
