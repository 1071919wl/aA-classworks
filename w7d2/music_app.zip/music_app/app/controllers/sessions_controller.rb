class SessionsController < ApplicationController

    def new
        render :new
    end
    
    def create
        #! why does param need to be called like this?
        #! has to do with our forms and the 'name=email[email]' input tags.
        user = User.find_by_credentials(params[:user][:email], 
                                        params[:user][:password])
        
        if user.nil?
            render :new
        else
            redirect_to user_url(user)            
        end
    end

    def destroy
        
    end
    
end
