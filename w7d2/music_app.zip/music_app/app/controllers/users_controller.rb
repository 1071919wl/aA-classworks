class UsersController < ApplicationController

    def new
        @user = User.new
        render :new
    end

    def show
        render :show
    end

    def create
        @user = User.new(user_params)

        if @user.save
            redirect_to user_url(@user.id)
        else
            render :new
        end
    end

    private
    def user_params
        #! Why do we use password. This is what the user provides us. 
        #! User isn't going to give us session_token/password_digest
        params.require(:user).permit(:email, :password)
    end
end
