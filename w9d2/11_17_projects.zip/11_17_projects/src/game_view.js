function GameView(game){
    this.game = game; 

}