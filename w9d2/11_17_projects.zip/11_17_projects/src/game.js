const Util = require("./util");
const Asteroid = require("./asteroid");




function Game(){
    this.asteroids = [];
    this.bullets = [];
    this.ships = [];


}

Game.prototype.step = function(){

};

Game.prototype.move = function(){

};

Game.prototype.checkCollisions = function(){

};

Game.prototype.draw = function(ctx){

}

Game.prototype.randomPosition = function randomPosition() {
  return [
    Game.DIM_X * Math.random(),
    Game.DIM_Y * Math.random()
  ];
};
module.exports = Game;