const MovingObject = require('./moving_object')
