import React from 'react';

const App = () => {
    return (
        <div>Hello</div>
    );
}

export default App;