import React from 'react';
import ReactDOM from 'react-dom';
import Widgets from './Widget';

document.addEventListener("DOMContentLoaded", () => {
  const root = document.getElementById("root");
  ReactDOM.render(<Widget/>, root);
});
