import React from 'react';
import Clock from './clock';
import Tab from './tabs'

let tabs = [{
    title: 'first',
    content: 'to-do',
}, 
    {title: 'second',
    content: 'i love dogs'
},
    {title: 'third',
    content: 'i love cats'
    
}];

class Widget extends React.Component {

    render() {
        return (
            <div>
                <Clock />
                <Tab tabs={tabs} />
            </div>
        )
    }

}
export default Widget;
