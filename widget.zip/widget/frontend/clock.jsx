import React from 'react';

class Clock extends React.Component {
    constructor(prop){
        super(prop);

        this.state = {
            date: new Date()
        }

        this.tick = this.tick.bind(this);

    }

    tick(){
        this.setState({date: new Date()})
    }

    componentDidMount() {
        let intervalId = setInterval(this.tick, 1000);
    }

    componentWillUnMount() {
        clearInterval(this.intervalId);
    }


    render(){
        return(
            <div>
                <h1>Clock</h1> 
                <div className="clock">
                    <span className="time"> Time:
                        <p>{`${this.state.date.getHours()}:${this.state.date.getMinutes()}:${this.state.date.getSeconds()}`} PDT</p>
                    </span>
                    <span className="date"> Date:
                        <p>{`${this.state.date.toDateString()}`} </p>
                    </span>
                </div>
            </div>
        )
        
    }
}

export default Clock;