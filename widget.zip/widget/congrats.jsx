import React from 'react';

const Congrats = () => <h1>Congratulations, you did it!</h1>;

export default Congrats;
