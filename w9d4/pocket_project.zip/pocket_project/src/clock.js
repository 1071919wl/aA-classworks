const { htmlGenerator } = require("./warmup");

class Clock {

    constructor(){
        const currentTimes = new Date();
        this.hours = currentTimes.getHours();
        this.minutes = currentTimes.getMinutes();
        this.seconds = currentTimes.getSeconds();
        htmlGenerator(this.printTime(), clockElement);
        setInterval(this._tick.bind(this), 1000);
    }


    printTime(){
        const result = `${this.hours}: ${this.minutes}: ${this.seconds}`;
        return result;
    }

    _tick(){
        this.seconds += 1;
        if(this.seconds === 60){
            this.seconds = 0;
            this.minutes += 1;
            if(this.minutes === 60){
                this.minutes = 0;
                this.hours = (this.hours + 1) % 24;
            }
        }
        this.printTime();
    }

}

const clockElement = document.getElementById('clock');
const clock1 = new Clock();


module.exports = Clock;
