
const dogs = {
  "Corgi": "https://www.akc.org/dog-breeds/cardigan-welsh-corgi/",
  "Australian Shepherd": "https://www.akc.org/dog-breeds/australian-shepherd/",
  "Affenpinscher": "https://www.akc.org/dog-breeds/affenpinscher/",
  "American Staffordshire Terrier": "https://www.akc.org/dog-breeds/american-staffordshire-terrier/",
  "Tosa": "https://www.akc.org/dog-breeds/tosa/",
  "Labrador Retriever": "https://www.akc.org/dog-breeds/labrador-retriever/",
  "French Bulldog": "https://www.akc.org/dog-breeds/french-bulldog/" 
};

const dogLinkCreator = (dogs) => {
  const dogArr = [];
  const dogName = Object.keys(dogs);

  dogName.forEach(dog => {
    const dogATag = document.createElement('a');
    dogATag.innerHTML = dog;
    dogATag.href = dogs[dog];

    const dogLiTag = document.createElement('li');
    dogLiTag.classList = 'dog-link';
    dogLiTag.appendChild(dogATag);

    dogArr.push(dogLiTag);
  });
  return dogArr;

}
// get the Html Element first

// append the array element to the html element
const attachDogLinks = () =>{
  const dogLinks = dogLinkCreator(dogs);
  const dogUl = document.querySelector('.drop-down-dog-list');
  dogLinks.forEach(li =>{
    dogUl.appendChild(li);
  })
};

attachDogLinks();

const handleEnter = () => {
  const dogView = document.querySelectorAll(".dog-link");
  dogView.forEach(dog =>dog.classList.add('done'))
}

const handleLeave = () =>{
  const dogView = document.querySelectorAll(".dog-link");
  dogView.forEach(dog => dog.classList.remove('done'))
}

const dog1s = document.querySelector(".drop-down-dog-list");

dog1s.addEventListener('mouseenter', handleEnter);
dog1s.addEventListener('mouseleave', handleLeave);
