// Phase 2: Enumerable
Array.prototype.myEach = function(callback) {
    // this.forEach(el => (callback(el)));
    this.forEach(function(el) {
        callback(el);
    });
}

const doubler = function(el) {
    return el * 2;
}
let arr = [1, 2, 3, 4, 5];

// console.log(arr.myEach(doubler));


//! THIS WILL DO A DOUBLE CALL BACK
// Array#myMap(callback) 
Array.prototype.myMap = function(cb) {
    let result = [];

    this.myEach(function(el) {
        result.push(cb(el));
    })
    // !cb in this case is the doubler
    // ES6
    // this.myEach(el => result.push(cb(el)))


    return result;
}
// console.log([2, 4, 6, 8].myMap(doubler));


// Array#myReduce(callback)
Array.prototype.myReduce = function(callback, acc) {
    let ar = [];
    for(let i = 0; i < this.length; i++) {
        ar.push(this[i])
    }
    let accum = acc;
    if(acc === undefined) {
        accum = this[0];
        ar.shift()
    }
    ar.myEach(el => accum = callback(accum, el) );
    // return this.myEach(callback(accum, ));
    return accum;
}

// without initialValue
let test = [1, 2, 3]
let test1 = test.myReduce(function(acc, el) {
    return acc + el;
  }); // => 6
console.log(test1)
  
  // with initialValue
let test2 = test.myReduce(function(acc, el) {
    return acc + el;
  }, 25); // => 31
console.log(test2)