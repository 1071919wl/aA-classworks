// Phase 3: Iteration

Array.prototype.bubbleSort = function() {
    let sorted = false
    while(sorted === false) {
        sorted = true;
        for(let i = 0; i < this.length - 1; i++) {
            if(this[i] > this[i + 1]) {
                [this[i], this[i + 1]] = [this[i + 1], this[i]];
                sorted = false;
            }
        }
    }
    return this;
}
// let arrange = [5, 3, 1, 6, 2];
// console.log(arrange.bubbleSort());


// String#substrings
String.prototype.substrings = function() {
    let arr = [];
    for(let i = 0; i < this.length; i++) {
        for(let j = i + 1; j <= this.length; j++ ){
            arr.push(this.substring(i, j));
        }
    }
    return arr;
}
let str = 'fox';
// console.log(str.substrings());
// f, o, x , ox, fo, fox

