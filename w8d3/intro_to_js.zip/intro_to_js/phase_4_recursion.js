// Phase 4: Recursion
// expression style!
Array.prototype.range = function(start, end){
    if( start === end ){
        return [];
    }else{
        return this[start] + this.range(start + 1, end);
    }
}

console.log([1, 2, 3, 4, 5, 6, 7].range(1, 5))



