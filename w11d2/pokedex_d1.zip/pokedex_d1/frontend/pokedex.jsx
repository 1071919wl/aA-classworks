import React from 'react';
import ReactDOM from 'react-dom';
import configureStore from './store'

//TESTING
import * as Util from './util/api_util';
import * as pokeActions from './actions/pokemon_actions';
//END TESTING


document.addEventListener('DOMContentLoaded', () => { 
    const store = configureStore();

//TESTING
    window.fetchAllPokemon = Util.fetchAllPokemon;
    window.receiveAllPokemon = pokeActions.receiveAllPokemon;
    window.store = store;
//END TESTING

    ReactDOM.render(<div>Pokedex</div>, document.getElementById('root'));
});
