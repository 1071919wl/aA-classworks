# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

Todo.destroy_all

t1 = Todo.create(title: 'buy milk', body: 'go to safeway', done: false);
t2 = Todo.create(title: 'buy beer', body: 'go to totalwine', done: true);
t3 = Todo.create(title: 'buy cheese', body: 'go to trader joes', done: true);
t4 = Todo.create(title: 'buy soda', body: 'go to burger king', done: false);
t5 = Todo.create(title: 'water the plants', body: 'fill up the water cannister', done: false);
t6 = Todo.create(title: 'put but christmas decorations', body: 'buy lights', done: true);
t7 = Todo.create(title: 'buy a christmas tree', body: 'buy a 7 ft tree', done: false);
t8 = Todo.create(title: 'mow the lawn', body: 'oil the lawnmower', done: true);